import datetime

def greetMe():
    hour = int(datetime.datetime.now().hour)

    if hour>=0 and hour<=12:
        print("Good Morning, sir")
    elif hour >12 and hour<=18:
        print("Good Afternoon, sir")

    else:
        print("Good Evening, sir")
        
    print("Please tell me, How can I help you?")
    
