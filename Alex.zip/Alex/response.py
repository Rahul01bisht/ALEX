def responses(query):
    try:
        with open("data.txt", "r") as file:
            for line in file:
                if ":" in line:
                    key, value = line.strip().split(":", 1)
                    if key.strip().lower() == query.strip().lower():
                        print("Alex:", value.strip())
                        return
                        
    except FileNotFoundError:
        print("Alex: Sorry, I don't understand that.")
        
    