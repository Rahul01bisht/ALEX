import webbrowser
import wikipedia

def takeCommand():
    query = input("You: ")
    return query
    
query = takeCommand().lower()    
    
def searchGoogle(query):
    if "google" in query:
        query = query.replace("alex", "")
        query = query.replace("search", "")
        query = query.replace("google", "")
        query = query.replace("on", "")
        print("This is what I found on Google:")

        try:
            # Direct Google search via browser
            webbrowser.open(f"https://www.google.com/search?q={query}")
            
            # Wikipedia summary
            result = wikipedia.summary(query, 1)
            print("Wikipedia Summary:", result)
        except Exception as e:
            print("No printable output available.")
            print("Error:", e)
            
def searchYT(query):
    if "youtube" in query:
        query = query.replace("alex", "")
        query = query.replace("youtube search", "")
        query = query.replace("youtube", "")
        web = "https://www.youtube.com/results?search_query=" + query
         
        webbrowser.open(web)
        print("Done sir")

def searchWikipedia(query):
    if "wikipedia" in query:
        print("searching from wikipedia . . . . ")
        query = query.replace("alex", "")
        query = query.replace("wikipedia search", "")
        query = query.replace("wikipedia", "")
        results =wikipedia.summary(query, sentences=2)
        print("According to wikipedia . . .")
        print(results)
        


if __name__ == ("__main__"):
    searchGoogle(query) 
    searchYT(query) 
    searchWikipedia(query)     
    searchinsta(query)       
