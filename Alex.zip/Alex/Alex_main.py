import requests
from bs4 import BeautifulSoup
from datetime import datetime


def takeCommand():
    query = input("You: ")
    return query
    
if __name__ == ("__main__"):

    while True:
        query = takeCommand().lower()
        
        if "wake up" in query:
            from greet import greetMe
            greetMe()
                        
        while True:
                                               
                if "go to sleep" in query:
                    print("okay sir , You can me call any time")
                    break
                
                elif "google" in query :
                    from search import searchGoogle
                    searchGoogle(query) 
                
                elif "youtube" in query :
                    from search import searchYT
                    searchYT(query)
                
                elif "wikipedia" in query :
                    from search import searchWikipedia 
                    searchWikipedia(query)   
                    
                elif "temperature" in query:
                    search = "temperature in almora"
                    url = f"https://www.google.com/search?q={search}"
                    headers = {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                    }
            
                    try:
                        r = requests.get(url, headers=headers)
                        data = BeautifulSoup(r.text, "html.parser")
                        temp = data.find("div", class_="BNeawe").text
                        print(f"Current {search} is {temp}")
                    except Exception as e:
                        print(f"An error occurred while fetching the temperature: {e}")
                    
                
                elif "remember that" in query:
                    rememberMessage = query.replace("remember ","")
                    rememberMessage = query.replace(" alex ","")
                    rememberMessage = query.replace("that","")
            
                    remember = open("remember.txt","a")
                    remember.write(rememberMessage)
                    remember.close()
                    
                
                elif "what do you remember" in query:
                    remember = open("remember.txt","r")
                    print("You told me " + remember.read())
                    
                   
                else:
                    from response import responses
                    responses(query)
                        
                query = takeCommand().lower()                                                                    